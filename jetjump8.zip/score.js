
class Score {

  show() {
    noStroke();
    fill(255);
    textSize(50);
    textFont(myFont);
    textAlign(CENTER);
    text(count, 500, 100);
  }
}
